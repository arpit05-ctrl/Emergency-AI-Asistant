// Get DOM elements
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');
const chatMessages = document.getElementById('chat-messages');

// Function to add a message to the chat
function addMessage(message, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    if (sender === 'user') {
        messageDiv.classList.add('user-message');
        messageDiv.innerHTML = `<strong>You:</strong> ${message}`;
    } else {
        messageDiv.classList.add('ai-message');
        messageDiv.innerHTML = `<strong>AI:</strong> ${message}`;
    }
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight; // Auto-scroll to bottom
}

// Replace 'YOUR_GROQ_API_KEY' with your actual Groq API key
const GROQ_API_KEY = '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';

// Function to get AI response using Groq API
async function getAIResponse(userMessage) {
    const prompt = `You are an emergency AI assistant. Provide helpful, accurate, and concise advice for the following emergency situation. Always emphasize calling emergency services like 112. User says: ${userMessage}`;
    const maxRetries = 3;
    let attempt = 0;

    while (attempt < maxRetries) {
        try {
            const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${GROQ_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'llama-3.1-8b-instant',
                    messages: [
                        {
                            role: 'system',
                            content: 'You are an emergency AI assistant. Always emphasize calling emergency services like 112 in India.'
                        },
                        {
                            role: 'user',
                            content: userMessage
                        }
                    ],
                    max_tokens: 150,
                    temperature: 0.7
                })
            });

            if (response.status === 429) {
                // Rate limit exceeded, wait and retry
                await new Promise(resolve => setTimeout(resolve, 5000 * (attempt + 1)));
                attempt++;
                continue;
            }

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            if (data && data.choices && data.choices[0] && data.choices[0].message) {
                return data.choices[0].message.content;
            } else {
                return "I'm sorry, I couldn't generate a response right now. Please call 911 for immediate help.";
            }
        } catch (error) {
            console.error('API Error:', error);
            attempt++;
            if (attempt >= maxRetries) {
                return "Error connecting to AI service. Please call 112 for emergency assistance.";
            }
            await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
    }
    return "Service temporarily unavailable. Please call 112 for emergency assistance.";
}

// Event listener for send button
sendButton.addEventListener('click', async () => {
    const message = userInput.value.trim();
    if (message) {
        addMessage(message, 'user');
        const aiResponse = await getAIResponse(message);
        addMessage(aiResponse, 'ai');
        userInput.value = '';
    }
});

// Allow sending message with Enter key
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendButton.click();
    }
});
